﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            // 게임 시작 시간 기록
            DateTime startTime = DateTime.Now;

            // 게임 실행 중...

            // 게임 종료 시간 기록
            DateTime endTime = DateTime.Now;

            // 게임 실행 시간 계산 (종료 시간 - 시작 시간)
            TimeSpan duration = endTime - startTime;

            // 게임 실행 시간 문자열로 변환
            string gameTime = duration.ToString();

            // 보낼 문자열
            string postData = "게임 실행 시간: " + gameTime;
            string postData2 = "게임 실행: " + gameTime;

            // HttpClient 인스턴스 생성
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    // 문자열을 보낼 URL
                    string url = "https://script.google.com/macros/s/AKfycbw7R2IWzXZR2l-W407Z2gJjaQ-oJx_oi78nRcaMWrAoELg7qQt_MuHQRrZ_5wZDQQuW1Q/exec";

                    // 문자열을 바이트 배열로 변환
                    byte[] byteArray = Encoding.UTF8.GetBytes(postData);

                    // HTTP POST 요청 생성
                    HttpResponseMessage response = await client.PostAsync(url, new ByteArrayContent(byteArray));

                    // 응답 확인
                    if (response.IsSuccessStatusCode)
                    {
                        string responseBody = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("서버로부터 받은 응답: " + responseBody);
                    }
                    else
                    {
                        Console.WriteLine("HTTP 요청 실패. 응답 코드: " + response.StatusCode);
                    }
                    byteArray = Encoding.UTF8.GetBytes(postData2);

                    // HTTP POST 요청 생성
                    response = await client.PostAsync(url, new ByteArrayContent(byteArray));

                    // 응답 확인
                    if (response.IsSuccessStatusCode)
                    {
                        string responseBody = await response.Content.ReadAsStringAsync();
                        Console.WriteLine("서버로부터 받은 응답: " + responseBody);
                    }
                    else
                    {
                        Console.WriteLine("HTTP 요청 실패. 응답 코드: " + response.StatusCode);
                    }

                }
                catch (HttpRequestException e)
                {
                    Console.WriteLine("HTTP 요청 실패: " + e.Message);
                }
            }
        }
    
    }
}
